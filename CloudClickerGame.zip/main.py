"""ICS3U1 Animation Creative Task
   By: Leo Liao

using timed events gotten from https://stackoverflow.com/questions/20318386/using-pygame-time-set-timer

using text.get_rect gotten from
https://stackoverflow.com/questions/23982907/pygame-how-to-center-text

800 by 600 needs to be dragged out a bit or the game gets cut off
"""
import code
code.entiregame()