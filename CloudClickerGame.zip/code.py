import pygame,sys,os,time
import random
from pygame.locals import *
from pygame.color import THECOLORS
pygame.init() 
clock=pygame.time.Clock()
SCREEN_WIDTH=800
SCREEN_HEIGHT=600
# setting up pygame window
window = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT)) 
pygame.display.set_caption('Cloud Clicker')
screen = pygame.display.get_surface()
# variables and constants that will be used later on
textcolour=('black')
screencolour=('white')
buttoncolour=("lightblue")
width = 3
x_list = []
y_list = []
cloudcolour = 'white'
burncolour = 'black'
lightningcolour = 'blue'
show = 'welcome'
pointcounter = 0
spentpoints = 0 
# Set up the font 
myfont = pygame.font.SysFont("Times New Roman", 25)
def entiregame():
  global show
  global mx
  global my
  running = True
  while running:
    print(show)
    pos = pygame.mouse.get_pos()
    butt = pygame.mouse.get_pressed()
    mx=pos[0]
    my=pos[1]
    print (mx, my, butt, show) #prints debug info to the DOS screen
  # printing screen based on show variable
    if show == 'upgrade':
      upgrademenu()
    elif show == 'welcome':
      startingscreen()
    elif show == 'rules':
      rules()
    elif show == 'start':
      game()
    events = pygame.event.get()
    for e in events:
      if e.type == QUIT:
        screen.fill(THECOLORS[screencolour])
        screen.blit(myfont.render("Goodbye", 1, (0,0,0)), (0,0))
        pygame.display.update()            
        time.sleep(1)
        running = False
      # checking for if select buttons have been clicked i.e start, rules
      if mx>262 and mx<262+77 and my>288 and my<288+25 and butt[0]==1 and show == 'welcome':
        show = 'start'
        time.sleep(0.5)
      if mx>461 and mx<461+78 and my>288 and my<288+25 and butt[0]==1 and show == 'welcome':
        show = 'rules'
      if mx>375 and mx<375+51 and my>438 and my<438+25 and butt[0]==1 and show == 'rules':
        show = 'welcome'
    clock.tick(60)
    pygame.display.flip()  

def background():
  screen.fill(THECOLORS["gray"])
  pygame.draw.rect(screen, THECOLORS["green"], [0,400,SCREEN_WIDTH,SCREEN_HEIGHT])
def startingscreen():
  background()
  start = myfont.render("START",True,THECOLORS[textcolour])
  rules = myfont.render("RULES",True,THECOLORS[textcolour])
  text = myfont.render("Click start to play!", True, THECOLORS[textcolour])
# centering the text 
  text_rect = text.get_rect(center=(SCREEN_WIDTH/2, SCREEN_HEIGHT/2-200))
  screen.blit(text,text_rect)
# drawing the buttons to give the user options
# start button
  text_rect = start.get_rect(center=(SCREEN_WIDTH/2-100, SCREEN_HEIGHT/2))
  pygame.draw.rect(screen, THECOLORS[buttoncolour],text_rect)
  screen.blit(start,text_rect)
  print ("text_rect1",text_rect)
# rules button
  text_rect = rules.get_rect(center=(SCREEN_WIDTH/2+100,SCREEN_HEIGHT/2))
  pygame.draw.rect(screen, THECOLORS[buttoncolour],text_rect)
  screen.blit(rules,text_rect)
  print ("text_rect2",text_rect)
def rules():
  screen.fill(screencolour)
  rule1 = myfont.render("1. Click on the cloud to make it strike lightning", True, THECOLORS[textcolour])
  rule2 = myfont.render("2. Upgrade the cloud to get more points",True, THECOLORS[textcolour])
  rule3 = myfont.render("3. Press the 'U' key to open up the upgrade menu or close it", True, THECOLORS[textcolour])
  rule4 = myfont.render("4. When in the upgrade menu, enter on your keyboard the key that corresponds",True, THECOLORS[textcolour])
# displaying the rules to the user 
  screen.blit(rule1,(0,0))
  screen.blit(rule2,(0,100))
  screen.blit(rule3,(0,200))
  screen.blit(rule4,(0,300))
# drawing a backbutton to go back to the starting screen
  backtext = myfont.render("Back", True, THECOLORS[textcolour])
  text_rect = backtext.get_rect(center=(SCREEN_WIDTH/2, SCREEN_HEIGHT/2+150))
  pygame.draw.rect(screen, THECOLORS[buttoncolour],text_rect)
  screen.blit(backtext,text_rect)
  print('rules screen', text_rect)
def burnmarks():
  for i in range (len(x_list)-1):
    if y_list[i] > 400:
      circlex=x_list[i]
      circley=y_list[i]
      pygame.draw.circle(screen, THECOLORS[burncolour],(circlex,circley),4)
def drawCloud(screen, mx, my):
  pygame.draw.rect(screen, THECOLORS[cloudcolour], [mx-100,my,150,50])
  pygame.draw.circle(screen, THECOLORS[cloudcolour],(mx-100,my+25),25)
  pygame.draw.circle(screen, THECOLORS[cloudcolour],(mx+50,my+25),25)
  pygame.draw.circle(screen, THECOLORS[cloudcolour],[mx-50,my-12],45)
  pygame.draw.circle(screen,THECOLORS[cloudcolour],[mx,my],45)
def lightningStrike(screen,mx,my):
# bolt section 1
  global randx3
  global randy3
  randx1 = int(random.randint(mx-100,mx+100))
  remainder=int((SCREEN_HEIGHT-my)/3)
  randy1 = int(random.randint(my+50,remainder+(my+50)))
  pygame.draw.line(screen, THECOLORS[lightningcolour],(mx,my+50), (randx1,randy1),width)
# bolt section 2
  randx2 = int(random.randint(mx-100,mx+100))
  randy2 = int(random.randint(randy1,remainder*2+(my+50)))
  pygame.draw.line(screen, THECOLORS[lightningcolour], (randx1,randy1), (randx2,randy2),width)
# final bolt section
  randx3 = int(random.randint(mx-100,mx+100))
  randy3 = int(random.randint(randy2,remainder*3+(my+50)))
  pygame.draw.line(screen,THECOLORS[lightningcolour],(randx2,randy2),(randx3,randy3),width)
  x_list.append(randx3)
  y_list.append(randy3)
# setting initial levels of upgrades
pointstrike = 1
strikes = 1
initialcost = 10
autostrike2 = 1
def game():
  global mx
  global my
  screen.fill(THECOLORS["gray"])
  pygame.draw.rect(screen, THECOLORS["green"], [0,400,SCREEN_WIDTH,SCREEN_HEIGHT])
  burnmarks()
  drawCloud(screen,mx,my)
  event = pygame.event.get()
  global show
  global counter
  global pointcounter
  global autostrike2
  global spentpoints
  # automatically repeats the lightning strike at intervals 
  handling = pygame.USEREVENT+1
  time_delay=(300)
  pygame.time.set_timer(handling, time_delay)
  for events in event:
    keys = pygame.key.get_pressed()
    if keys[K_u]==1:
      show = 'upgrade'
    # since all levels start at 1, if statement is used to prevent auto striking at level 1
    if autostrike2>1:
      if events.type == handling:
        autostrike()
    if events.type == pygame.MOUSEBUTTONDOWN:
# making the cloud strike multiple times per click
      if strikes == 1:
        lightningStrike(screen,mx,my)
        pointcounter+=pointstrike
      elif strikes >1:
        for i in range(1,strikes):
          lightningStrike(screen,mx,my)
          pointcounter+=pointstrike
          print('pointcounter',pointcounter)
# this section auto strikes depending on how much the user has leveled up the auto strike upgrade
  points = myfont.render("Upgrade points: {}".format((pointcounter)-spentpoints),True,THECOLORS[textcolour])
  screen.blit(points,(0,0))
def upgrademenu():
  global spentpoints
  global show
  global autostrike2
  global pointstrike
  global strikes
  global initialcost
# resetting the screen to just white inorder to make it more legible
  screen.fill(THECOLORS[screencolour])
  points = myfont.render("Upgrade points: {}".format((pointcounter)-spentpoints),True,THECOLORS[textcolour])
  screen.blit(points,(0,0))
  event = pygame.event.get()
# calculating the values of the next level based on current upgrades
  nextlevel = '{} milliseconds'.format(round(10000/(autostrike2+1)))
  nextlevel2 = '{} points'.format(2+pointstrike)
  nextlevel3 = '{} times'.format(1+strikes)
  reminder = myfont.render("Enter the number that corresponds to the upgrade you want", True, THECOLORS[textcolour])
  upgrade1 = myfont.render('1. Lightning now auto strikes every {}'.format(nextlevel),True, THECOLORS[textcolour])
  upgrade2 = myfont.render('2. You get {} per strike'.format(nextlevel2),True, THECOLORS[textcolour])
  upgrade3 = myfont.render('3. The cloud now strikes {} per click'.format(nextlevel3),True, THECOLORS[textcolour])
  screen.blit(reminder,(0,100))
  screen.blit(upgrade1,(0,200))
  screen.blit(upgrade2,(0,300))
  screen.blit(upgrade3,(0,400))
# displaying the cost of each upgrade
  cost1 = myfont.render("{}".format(initialcost*(autostrike2)), True, THECOLORS[textcolour])
  cost2 = myfont.render('{}'.format(initialcost*(pointstrike)), True, THECOLORS[textcolour])
  cost3 = myfont.render('{}'.format(initialcost*(strikes)), True, THECOLORS[textcolour])
  screen.blit(cost1, (SCREEN_WIDTH-150,200))
  screen.blit(cost2, (SCREEN_WIDTH-150,300))
  screen.blit(cost3, (SCREEN_WIDTH-150,400))
  # checking if the player has enough points to buy each upgrade
  for events in event:
    keys = pygame.key.get_pressed()
    if keys[K_u]==1:
      show = 'start'
  # making variables to shorten the calculations and reduce confusion 
    upgrade1cost = (initialcost*(autostrike2))
    upgrade2cost = (initialcost*(pointstrike))
    upgrade3cost = (initialcost*(strikes))
    if keys[K_1] and ((pointcounter-spentpoints)-upgrade1cost)>=0:
      spentpoints+=(initialcost*(autostrike2))
      autostrike2+=1
    if keys[K_2] and ((pointcounter-spentpoints)-upgrade2cost)>=0:
      spentpoints+=(initialcost*(pointstrike))
      pointstrike+=1
    if keys[K_3] and ((pointcounter-spentpoints)-upgrade3cost)>=0:
      spentpoints+=(initialcost*(strikes))
      strikes+=1
    print (autostrike2)
    print (pointstrike)
    print (strikes)
def autostrike():
   global pointcounter
   if strikes == 1:
    lightningStrike(screen,mx,my)
    pointcounter+=pointstrike
   elif strikes >1:
    for i in range(1,strikes):
      lightningStrike(screen,mx,my)
      pointcounter+=pointstrike
      print('pointcounter',pointcounter)