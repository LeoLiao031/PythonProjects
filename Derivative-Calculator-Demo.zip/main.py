import sympy
from sympy import *
from sympy.solvers import solve
from sympy import roots, solve_poly_system


# this function takes in an array of coefficients which represents f(x) and calculates f'(x)
def differentiatePolynomial (coefficientarray):
  termnumber = len(coefficientarray)
  finalarray = []
  # for loop that will multiply the coefficient by it's exponent 
  # exponent is found by looking at the length of the coefficient array as it's ordered highest exponent to lowest
  for term in range(termnumber - 1):
    finalarray.append(coefficientarray[term]*(termnumber-term-1))
  return finalarray
  
# this function takes in the input from the user and turns it into a polynomial that can be parsed for information
def readinput(my_poly):
  # changing the user input into something that can be parsed
  my_poly = appendasterisk(my_poly)
  coefficientarray = []
  my_poly = sympy.polys.polytools.poly_from_expr(my_poly)[0]
  coefficientarray = my_poly.all_coeffs()
  return coefficientarray

# this function takes in a function and finds its derivative multiple times 
def nthderivative (function, times):
  times = int(times)
  # looping a number of times to find the derivative that many times
  for x in range (times):
    function = readinput(function)
    function = differentiatePolynomial(function)
    function = readarray(function)
  return function

# this function adds an asterisk where multiplication occurs as the function can't be read without them
def appendasterisk (function):
  function = function.replace("^","**")
  function = function.replace(")(",")*(")
  function = function.replace("1x", "1*x")
  function = function.replace("2x", "2*x")
  function = function.replace("3x", "3*x")
  function = function.replace("4x", "4*x")
  function = function.replace("5x", "5*x")
  function = function.replace("6x", "6*x")
  function = function.replace("7x", "7*x")
  function = function.replace("8x", "8*x")
  function = function.replace("9x", "9*x")
  function = function.replace("0x", "0*x")
  function = function.replace(" ","")
  function = function.replace("1(", "1*(")
  function = function.replace("2(", "2*(")
  function = function.replace("3(", "3*(")
  function = function.replace("4(", "4*(")
  function = function.replace("5(", "5*(")
  function = function.replace("6(", "6*(")
  function = function.replace("7(", "7*(")
  function = function.replace("8(", "8*(")
  function = function.replace("9(", "9*(")
  function = function.replace("0(", "0*(")
  function = function.replace("-(","-1*(")
  return function

# this function takes in a quotient and finds the derivative 
def nthderivativequotient (function,times):
  times = int(times)
  finalfunction = function
  for x in range (times):
    my_poly = finalfunction
    my_poly = appendasterisk(my_poly)
    splitfunction = my_poly.split("/")
    numerator = splitfunction[0]
    denominator = splitfunction[1]
    global functionnth
    numeratorconst = False
    denominatorconst = False
    try:
      # testing the case that one of the factors is a constant 
      numerator = int(numerator)
      numerator = str(numerator)
      numeratorconst = True
    except:
      numerator = readinput(numerator)
    try:
      denominator = int(denominator)
      denominator = str(denominator)
      denominatorconst = True
    except:
      denominator = readinput(denominator)
  
    # case where both the numerator and denominator are non constant functions
    if numeratorconst == False and denominatorconst == False:
      print()
      originalnumerator = readarray(numerator)
      differentiatedQuotient = differentiateQuotient(numerator, denominator)
      theFinishedFunction = readarray(differentiatedQuotient)
      originalfunction =  simplify("("+originalnumerator+")"+"/"+"("+readarray(denominator)+")")
      print("Original function: "+originalfunction)
      if originalfunction == "1":
        print("Differentiated function: 0")
      else:
        finalfunction = simplify("("+theFinishedFunction+")"+"/"+"("+readarray(denominator)+")"+"^2")
        functionnth = finalfunction
    # case where the numerator is a constant but the denominator is a non constant function
    elif numeratorconst == True and denominatorconst == False:
      placeholder = int(numerator)
      numerator = []
      numerator.append(placeholder)
      differentiatedQuotient = differentiateQuotient(numerator,denominator)
      theFinishedFunction = readarray(differentiatedQuotient)
      print()
      placeholder = str(placeholder)
      originalfunction = simplify("("+placeholder+")"+"/"+"("+readarray(denominator)+")")
      print("Original function: "+originalfunction)
      finalfunction = simplify("("+theFinishedFunction+")"+"/"+"("+readarray(denominator)+")"+"^2")
      functionnth = finalfunction
    elif numeratorconst == False and denominatorconst == True:
      coefficientfunction2 = denominator
      denominator = []
      denominator.append(coefficientfunction2)
      differentiatedQuotient = differentiateQuotient(numerator, denominator)
      theFinishedFunction = readarray(differentiatedQuotient)
      print()
      originalfunction = simplify("("+readarray(numerator)+")"+"/"+denominator)
      print("Original function: "+originalfunction)
      finalfunction = simplify("("+theFinishedFunction+")"+"/"+"("+denominator+")"+"^2")
      print("Differentiated function: "+finalfunction)
      functionnth = finalfunction
    
  return function
  
# this function takes in two arrays and calculates the derivitive through product rule
def differentiateProduct (function1, function2):
  # calculating the length of the arrays 
  termnumber1 = len(function1)
  termnumber2 = len(function2)

  # using the function that calculates the derivitive of a polynomial to find p'(x) and g'(x)
  derivitive1 = differentiatePolynomial(function1)
  derivitive2 = differentiatePolynomial(function2)
  
  differentiatedCoefficient1 = []   # coefficients of p(x)q'(x)
  differentiatedCoefficient2 = []   # coefficients of q(x)p'(x)
  exponent1 = []                    # exponents of p(x)q'(x)
  exponent2 = []                    # exponents of p'(x)q(x)
  # this loop foils p(x)'q(x)
  for term in range(len(function1)):
    for x in range(len(derivitive2)):
      differentiatedCoefficient1.append(function1[term]*derivitive2[x])
      exponent1.append((termnumber1 - term - 1) + (termnumber2 - x - 2))

  # this loop foils p'(x)q(x)
  for term in range(len(function2)):
    for x in range(len(derivitive1)):
      differentiatedCoefficient2.append(function2[term]*derivitive1[x])
      exponent2.append((termnumber2 - term - 1) + (termnumber1 - x - 2))

  differentiatedCoefficientsSimplified = []
  exponentSimplified = []

  #find max exponent across both terms
  maxExponent = exponent1[0]
  for term in range(len(exponent1)):
    if exponent1[term] > maxExponent:
      maxExponent = exponent1[term]
  for term in range(len(exponent2)):
    if exponent2[term] > maxExponent:
      maxExponent = exponent2[term]
      
  #find min exponent across both terms
  minExponent = exponent1[0]
  for term in range(len(exponent1)):
    if exponent1[term] < minExponent:
      minExponent = exponent1[term]
  for term in range(len(exponent2)):
    if exponent2[term] < minExponent:
      minExponent = exponent2[term]



  # in order from the highest to lowest exponent, sum up all coefficients belonging to each exponent and
  # add it to a new array (along with a secondary array w/ the exponents in the same corresponding indexes)
  # (note: if the sum is 0, they're not appended to the array)
  for i in range(maxExponent, minExponent - 1, -1): 
    sum = 0
    for j in range(len(exponent1)):
      if exponent1[j] == i:
        sum += differentiatedCoefficient1[j]
    for j in range(len(exponent2)):
      if exponent2[j] == i:
        sum += differentiatedCoefficient2[j]

    differentiatedCoefficientsSimplified.append(sum)
    exponentSimplified.append(i) 
  
  return differentiatedCoefficientsSimplified

# this function takes in a numerator and denominator and returns the derivitive through the quotient rule
# it follows the same looping formats as product rule except subtracts instead of adding
# function1 is numerator 
# function2 is denominator
def differentiateQuotient(function1, function2):
  termnumber1 = len(function1)
  termnumber2 = len(function2)
  
  derivitive1 = differentiatePolynomial(function1)
  derivitive2 = differentiatePolynomial(function2)
  
  differentiatedCoefficient1 = []   # coefficient p(x)q'(x)
  differentiatedCoefficient2 = []   # coefficient q(x)p'(x)
  exponent1 = []                    # exponent p(x)q'(x)
  exponent2 = []                    # exponent p'(x)q(x)
          
  for term in range(len(function1)):
    for x in range(len(derivitive2)):
      differentiatedCoefficient1.append(function1[term]*derivitive2[x])
      exponent1.append((termnumber1 - term - 1) + (termnumber2 - x - 2))

  for term in range(len(function2)):
    for x in range(len(derivitive1)):
      differentiatedCoefficient2.append(function2[term]*derivitive1[x])
      exponent2.append((termnumber2 - term - 1) + (termnumber1 - x - 2))

  differentiatedCoefficientsSimplified = []
  exponentSimplified = []

  #find max exponent across both terms
  maxExponent = exponent1[0]
  for term in range(len(exponent1)):
    if exponent1[term] > maxExponent:
      maxExponent = exponent1[term]
  for term in range(len(exponent2)):
    if exponent2[term] > maxExponent:
      maxExponent = exponent2[term]

      
  #find min exponent across both terms
  minExponent = exponent1[0]
  for term in range(len(exponent1)):
    if exponent1[term] < minExponent:
      minExponent = exponent1[term]
  for term in range(len(exponent2)):
    if exponent2[term] < minExponent:
      minExponent = exponent2[term]


  #in order from the highest to lowest exponent, sum up all coefficients belonging to each exponent and
  #add it to a new array (along with a secondary array w/ the exponents in the same corresponding indexes)
  #(note: if the sum is 0, they're not appended to the array)
  for i in range(maxExponent, minExponent - 1, -1): 
    sum = 0
    for j in range(len(exponent1)):
      if exponent1[j] == i:
        sum -= differentiatedCoefficient1[j]
    for j in range(len(exponent2)):
      if exponent2[j] == i:
        sum += differentiatedCoefficient2[j]

    differentiatedCoefficientsSimplified.append(sum)
    exponentSimplified.append(i) 

  return differentiatedCoefficientsSimplified

# this function takes in an innerfunction and outerfunction and returns the derivitive using chainrule 
def differentiateChain(innerfunction, outerfunction):
  innerderivitive = differentiatePolynomial(innerfunction)
  outerderivitive = differentiatePolynomial(outerfunction)

  # turning the arrays into the way that we see polynomial functions as string manipulation will be used
  innerfunctionText = readarray(innerfunction)
  outerderivitiveText = readarray(outerderivitive)

  # outputting the derivitive by replacing the usual f'(x) with f'(g(x)) - g(x) replaces the x
  result = outerderivitiveText.replace("x", "(" + innerfunctionText + ")")
  # this part is the g'(x)
  result += "*(" + readarray(innerderivitive) + ")"
  
  return result
  
# this function takes in an array of coefficients and turns in into a polynomial function that we recognize 
# through deducing the exponents attached to each term
def readarray (function):
  termnumber = len(function)
  result = ""

  # loop that goes through each coefficient in the array and adds its corresponding sign to make it a recognizable polynomial
  for term in range(termnumber):
    if function[term] == 0:
      continue
    
    sign = " + "
    if function[term] > 0 and term == 0:
      sign = ""
    elif function[term] < 0 and term == 0:
      sign = "-"
    elif function[term] < 0:
      sign = " - "

    if term == termnumber - 1:
      result += sign + str(abs(function[term]))
      continue
    elif term == termnumber - 2:
      result += sign + str(abs(function[term])) + "x"
      continue
    # this does string concatenation and turns all the calculated values into the polynomial
    result += sign + str(abs(function[term])) + "x^" + str(termnumber - term - 1)

  return result

def simplify(function):
  # cleaning up back into parseable format
 function = function.replace("^","**")
 function = function.replace("x","*x")
 function = function.replace(" ","")
 function = function.replace(")(",")*(")
 x = sympy.Symbol('x')
 function = str(sympy.factor(function))
 expr = function.replace(")*(",")(")
 expr = expr.replace("**", "^")
 expr = expr.replace("*", "")
 return expr
  
  
######################## POLYNOMIAL DIFFERENTIATION #############################################
    
# asking the user how many terms are in their polynomial function
def polynomial():
  coefficientarray = []
  inputtedfunction = input("Input polynomial: ")
  try:
    inputtedfunction = int(inputtedfunction)
    print()
    print("Original function: "+ str(inputtedfunction))
    print()
    print("Differentiated function: 0")
  except:
    
    coefficientarray = readinput(inputtedfunction)
    
    finalarray = differentiatePolynomial(coefficientarray)

    # outputting both functions in polynomial form for the user
    print()
    print("Original function:")
    print (simplify((readarray(coefficientarray))))
    print()
  
    print("Differentiated function:")
    print (simplify(readarray(finalarray)))
    global functionnth 
    functionnth = simplify(readarray(finalarray))


######################## PRODUCT RULE #############################################

def product():
  firstfactor = input("Input the first factor: ")
  secondfactor = input("Input the second factor: ")
  constant1 = False
  constant2 = False
  global functionnth
  try:
    # testing the case that one of the factors is a constant 
    firstfactor = int(firstfactor)
    firstfactor = str(firstfactor)
    constant1 = True
  except:
    firstfactor = readinput(firstfactor)
  try:
    secondfactor = int(secondfactor)
    secondfactor = str(secondfactor)
    constant2 = True
  except:
    secondfactor = readinput(secondfactor)
  print()
  print("Original function: ")
  if constant1==False and constant2==False:
    print(simplify("(" + readarray(firstfactor) + ")  (" + readarray(secondfactor) + ")"))
    print()
    print("Differentiated function: ")
    differentiatedProduct = differentiateProduct(firstfactor, secondfactor)
    print(simplify(readarray(differentiatedProduct)))
    functionnth = simplify(readarray(differentiatedProduct))
  elif constant1==True and constant2 == False:
    print(simplify("("+firstfactor+")("+readarray(secondfactor)+")"))
    print()
    print("Differentiated function: ")
    placeholder = firstfactor
    firstfactor= []
    firstfactor.append(int(placeholder))
    differentiatedProduct = differentiateProduct(firstfactor, secondfactor)
    print(simplify(readarray(differentiatedProduct)))
    functionnth = simplify(readarray(differentiatedProduct))
  elif constant1== False and constant2 == True:
    print(simplify("("+readarray(firstfactor)+")("+secondfactor+")"))
    print()
    print("Differentiated function: ")
    placeholder = secondfactor
    secondfactor = []
    secondfactor.append(int(placeholder))
    differentiatedProduct = differentiateProduct(secondfactor, firstfactor)
    print(simplify(readarray(differentiatedProduct)))
    functionnth = simplify(readarray(differentiatedProduct))
  else:
    print(str(int(firstfactor)*int(secondfactor)))
    print()
    print("Differentiated function: ")
    print("0")

####################### QUOTIENT RULE ####################################################
# get user to input numerator and denominator 
# 
def quotient():
  # arrays that hold the different coefficients and the derivitive of the original function
  numerator = input("Input your numerator: ")
  denominator = input("Input your denominator: ")
  global functionnth
  numeratorconst = False
  denominatorconst = False
  try:
    # testing the case that one of the factors is a constant 
    numerator = int(numerator)
    numerator = str(numerator)
    numeratorconst = True
  except:
    numerator = readinput(numerator)
  try:
    denominator = int(denominator)
    denominator = str(denominator)
    denominatorconst = True
  except:
    denominator = readinput(denominator)

  # case where both the numerator and denominator are non constant functions
  if numeratorconst == False and denominatorconst == False:
    print()
    originalnumerator = readarray(numerator)
    differentiatedQuotient = differentiateQuotient(numerator, denominator)
    theFinishedFunction = readarray(differentiatedQuotient)
    originalfunction =  simplify("("+originalnumerator+")"+"/"+"("+readarray(denominator)+")")
    print("Original function: "+originalfunction)
    if originalfunction == "1":
      print("Differentiated function: 0")
    else:
      finalfunction = simplify("("+theFinishedFunction+")"+"/"+"("+readarray(denominator)+")"+"^2")
      print("Diffentiated function: "+finalfunction)
      functionnth = finalfunction
  # case where the numerator is a constant but the denominator is a non constant function
  elif numeratorconst == True and denominatorconst == False:
    placeholder = int(numerator)
    numerator = []
    numerator.append(placeholder)
    differentiatedQuotient = differentiateQuotient(numerator,denominator)
    theFinishedFunction = readarray(differentiatedQuotient)
    print()
    placeholder = str(placeholder)
    originalfunction = simplify("("+placeholder+")"+"/"+"("+readarray(denominator)+")")
    print("Original function: "+originalfunction)
    finalfunction = simplify("("+theFinishedFunction+")"+"/"+"("+readarray(denominator)+")"+"^2")
    print("Differentiated function: "+finalfunction)
    functionnth = finalfunction
  elif numeratorconst == False and denominatorconst == True:
    coefficientfunction2 = denominator
    denominator = []
    denominator.append(coefficientfunction2)
    differentiatedQuotient = differentiateQuotient(numerator, denominator)
    theFinishedFunction = readarray(differentiatedQuotient)
    print()
    originalfunction = simplify("("+readarray(numerator)+")"+"/"+denominator)
    print("Original function: "+originalfunction)
    finalfunction = simplify("("+theFinishedFunction+")"+"/"+"("+denominator+")"+"^2")
    print("Differentiated function: "+finalfunction)
    functionnth = finalfunction

  

####################### CHAIN RULE ####################################################

def chain():

  # arrays that hold the coefficients of the inner and outer functions
  coefficientinnerfunction = []
  coefficientouterfunction = []
  global functionnth
  innerfunctioninput = input("Input your inner function: ")
  outerfunctioninput = input("Input your outer function: ")
  try:
    innerfunctioninput = int(innerfunctioninput)
    innerfunctioninput = str(innerfunctioninput)
    coefficientouterfunction = readinput(outerfunctioninput)
    print("Original function: ")
    print(str(readarray(coefficientouterfunction).replace("x", "(" + innerfunctioninput+ ")")))
    print("Differentiated function: ")
    print("0")
  except:
    coefficientinnerfunction = readinput(innerfunctioninput)
    coefficientouterfunction = readinput(outerfunctioninput)
    print()
    print("Original function: ")
    original = str(readarray(coefficientouterfunction).replace("x", "(" + readarray(coefficientinnerfunction) + ")"))
    original = original.replace("(", "*(")
    print(simplify(original))
    print()
  
    print("Differentiated function: ")
    differentiated = (differentiateChain(coefficientinnerfunction, coefficientouterfunction))
    differentiated = appendasterisk(differentiated)
  
    print(simplify(differentiated))
    functionnth = simplify(differentiated)
def sort_key(xy):
  return xy[1]
def eva():
  # find f'(x), find all values of x where f'(x) = 0, find the value of f(x) using f'(x)=0 and endpoint of interval then pick values
  # asking the user for f(x)
  function = input("Enter your polynomial function: ")
  startpoint = input("Enter the start point: ")
  endpoint = input("Enter your end point: ")
  function = readinput(function)
  differentiated = differentiatePolynomial(function)
  differentiated = readarray(differentiated)
  differentiated = appendasterisk(differentiated)
  function = readarray(function)
  # have to turn function into something that is legible by the function reader
  x = sympy.Symbol('x')
  function = appendasterisk(function)
  function = sympy.polys.polytools.poly_from_expr(function)[0]
  yarray = []
  # now that f(x) is found solve for x to find local max and min
  solutions = sympy.solvers.solvers.solve(differentiated, x)
  print (solutions)
  # now that we have factors, replug in these values into the original function to find the y values
  # for loop that will fill an array with the y values by going through each possible candidates
  for i in range (len(solutions)):
    # appending the x values and y values as a tuple to the array
    if solutions[i] > int(startpoint) and solutions[i] < int(endpoint):
      yarray.append((solutions[i], function.subs(x,solutions[i])))
  # now check the values that the end points give
  yarray.append(((startpoint), function.subs(x,startpoint)))
  yarray.append(((endpoint), function.subs(x,endpoint)))
  print(yarray)
  # now sort from highest to lowest and pick out the first value and last value of the array
  yarray.sort(key=sort_key, reverse=True)
  # catching any edge case where there's multiple solutions to the min or max
  print(yarray)
  absolutemax = str(yarray[0])
  absolutemax = absolutemax.replace("'","")
  absolutemin = str(yarray[-1])
  absolutemin = absolutemin.replace("'", "")
  print("Absolute max: "+absolutemax)
  extrasolutions = []
  extrasolutionsmin = []
  # turning the list of tuples into a 2D array as I want to isolate y values to compare
  yarray = [list(item) for item in yarray]
  maxy = yarray[0][1]
  for x in range (len(yarray)):
    if yarray[x][1] == maxy:
      extrasolutions.append(yarray[x])
  # now do the reverse by counting backward for the minimums
  miny = yarray[-1][1]
  for x in range (len(yarray)):
    if yarray[x][1] == miny:
      extrasolutionsmin.append(yarray[x])
  print(maxy)
  print(miny)
  print(extrasolutions)
  print(extrasolutionsmin)
  print("Absolute min: "+absolutemin)
  
    
    
  
######################## MAIN #############################################
x = True
while x == True:
  print("Enter 1 for polynomials, 2 for product rule,")
  print("3 for quotient rule, 4 for chain rule ")
  print("5 to take higher order derivative")
  print("6 to find absolute min and max")
  choice = input("7 to exit: ")
  if choice == "1":
    polynomial()
  elif choice == "2":
    product()
  elif choice == "3":
    quotient()
  elif choice == "4":
    chain()
  elif choice == "7":
    print("Program is now done running!")
    x = False
  elif choice== "5":
    nth = input("What is the nth derivative you want to find: ")
    try:
      print(nthderivative(functionnth, nth))
    except:
      x = functionnth.split("/")
      if len(x) == 2:
        print(nthderivativequotient(functionnth,nth))
      else:
        print("Cannot find next higher derivative")
        print("")
  elif choice == "6":
    eva()

